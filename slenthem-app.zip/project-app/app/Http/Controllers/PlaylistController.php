<?php

namespace App\Http\Controllers;

use App\Models\Playlist;
use Illuminate\Http\Request;

class PlaylistController extends Controller
{
    public function index()
    {
        return view('playlist.index', [
            'playlist' => Playlist::all(),
        ]);
    }

    public function create()
    {
        return view('playlist.create');
    }

    public function store(Request $request)
    {
        $playlist = new Playlist();
        $playlist->nama_playlist = $request->input('nama_playlist');
        $playlist->deskripsi = $request->input('deskripsi');
        $playlist->id_user = $request->user()->id;
        $playlist->save();

        return redirect('/playlist');
    }

    public function show($id)
    {
        $playlist = Playlist::findOrFail($id);

        return view('playlist.show', [
            'playlist' => $playlist,
        ]);
    }

    public function edit($id)
    {
        $playlist = Playlist::findOrFail($id);

        return view('playlist.edit', [
            'playlist' => $playlist,
        ]);
    }

    public function update(Request $request, $id){
        
    }
}