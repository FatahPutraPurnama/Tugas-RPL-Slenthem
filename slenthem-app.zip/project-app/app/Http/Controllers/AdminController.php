<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        $admin = Admin::all();

        return view('admin.index', [
            'admin' => $admin,
        ]);
    }

    public function create()
    {
        return view('admin.create');
    }

    public function store(Request $request)
    {
        $admin = new Admin();
        $admin->username = $request->input('username');
        $admin->email = $request->input('email');
        $admin->password = $request->input('password');
        $admin->save();

        return redirect('/admin');
    }

    public function show($id)
    {
        $admin = Admin::findOrFail($id);

        return view('admin.show', [
            'admin' => $admin,
        ]);
    }

    public function edit($id)
    {
        $admin = Admin::findOrFail($id);

        return view('admin.edit', [
            'admin' => $admin,
        ]);
    }

    public function update(Request $request, $id)
    {
        $admin = Admin::findOrFail($id);
        $admin->username = $request->input('username');
        $admin->email = $request->input('email');
        $admin->password = $request->input;
    }
}