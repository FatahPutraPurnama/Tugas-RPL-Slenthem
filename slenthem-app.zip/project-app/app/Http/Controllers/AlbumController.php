<?php

namespace App\Http\Controllers;

use App\Models\Album;
use App\Models\Lagu;
use Illuminate\Http\Request;

class AlbumController extends Controller
{
    public function index()
    {
        $album = Album::with('lagu')->get();

        return view('album.index', [
            'album' => $album,
        ]);
    }

    public function create()
    {
        return view('album.create');
    }

    public function store(Request $request)
    {
        $album = new Album();
        $album->nama_album = $request->input('nama_album');
        $album->deskripsi = $request->input('deskripsi');
        $album->id_label = $request->input('id_label');
        $album->tahun_rilis = $request->input('tahun_rilis');
        $album->save();

        foreach ($request->input('lagu') as $id_lagu) {
            $album->lagu()->attach($id_lagu);
        }

    }
}