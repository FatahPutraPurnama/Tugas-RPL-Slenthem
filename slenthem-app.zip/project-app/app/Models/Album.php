<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Album extends Model
{
    protected $table = 'album';
    protected $fillable = [
        'nama_album',
        'deskripsi',
        'id_label',
        'tahun_rilis',
    ];

    public function label()
    {
        return $this->belongsTo('App\Models\Label', 'id_label');
    }

    public function lagu()
    {
        return $this->hasMany('App\Models\Lagu', 'id_album');
    }
}
