<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Playlist extends Model
{
    protected $table = 'playlist';
    protected $fillable = [
        'nama_playlist',
        'deskripsi',
        'id_user',
    ];

    public function user()
    {
        return $this->belongsTo('App\Models\Pengguna', 'id_user');
    }
}
