<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Song extends Model
{
    protected $fillable = [
        'id_song',
        'title_song',
        'song_writer',
    ];

    public function showSong()
    {
        return view('songs.show', compact('song'));
    }
}
