<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class user extends Model
{
    protected $fillable = [
        'id_user',
        'nama_user',
        'email',
        'no_telp',
        'password'
    ];
}
