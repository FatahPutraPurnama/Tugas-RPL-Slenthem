<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArtistBand extends Model
{
    protected $fillable = [
        'id_artist',
        'nama_artist',
        'genre',
        'email_artist',
    ];
}
